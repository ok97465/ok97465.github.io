"""Example NumPy style docstrings.

[Description]

Example
-------
[Example]


Notes
-----
[Notes]

References
----------
.. [] 

:filename: 
:author: ok97465
:date created: 8/22/18 4:48 PM 
"""
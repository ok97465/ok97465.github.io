def ipython_clear(b_plot_close=False):
    """ipython의 변수를 메모리에서 삭제하고 Plot 창을 닫는다.

    Parameters
    ----------
    b_plot_close : bool
        Plot 창을 닫을 지 여부 (the default is False)

    """

    from IPython import get_ipython

    if get_ipython() is not None:
        import sys

        get_trace = getattr(sys, 'gettrace', None)
        if get_trace() is None:
            import gc

            if b_plot_close:
                from matplotlib import pyplot
                figs = list(map(pyplot.figure, pyplot.get_fignums()))
                for fig in figs:
                    fig.clear()
                pyplot.close('all')

            get_ipython().magic('reset -sf')

            gc.collect()


def load_func_frequently(ns):
    """자주 사용하는 자주 사용하는 함수를 Load한다

    Parameters
    ----------
    ns : dict
        Function을 불러와서 저장할 NameSpace

    Examples
    --------
    load_func_frequently(globals())

    """

    if ns is not None:
        import numpy as np
        import numpy.random_intel as np_rand
        import matplotlib.pyplot as plt
        import oklib.signal as oksignal
        from oklib.file import save_vars, load_vars
        from oklib.plot import imagesc
        from numpy.linalg import norm, svd

        ns['np'] = np
        ns['fft'] = np.fft.fft
        ns['ifft'] = np.fft.ifft
        ns['fftshift'] = np.fft.fftshift
        ns['ifftshift'] = np.fft.ifftshift
        ns['fft2'] = np.fft.fft2
        ns['ifft2'] = np.fft.ifft2

        ns['sqrt'] = np.sqrt
        ns['angle'] = np.angle
        ns['rad2deg'] = np.rad2deg
        ns['deg2rad'] = np.deg2rad
        ns['unwrap'] = np.unwrap

        ns['sin'] = np.sin
        ns['cos'] = np.cos
        ns['tan'] = np.tan
        ns['arcsin'] = np.arcsin
        ns['arccos'] = np.arccos
        ns['arctan'] = np.arctan

        ns['ones'] = np.ones
        ns['zeros'] = np.zeros
        ns['array'] = np.array
        ns['mean'] = np.mean
        ns['sum'] = np.sum
        ns['amin'] = np.amin
        ns['amax'] = np.amax
        ns['argmin'] = np.argmin
        ns['argmax'] = np.argmax

        ns['diff'] = np.diff
        ns['cumsum'] = np.cumsum
        ns['interp'] = np.interp

        ns['exp'] = np.exp

        ns['conj'] = np.conj

        ns['arange'] = np.arange
        ns['linspace'] = np.linspace

        ns['pi'] = np.pi

        ns['randn'] = np_rand.randn
        ns['standard_normal'] = np_rand.standard_normal

        ns['plt'] = plt
        ns['plot'] = plt.plot
        ns['hist'] = plt.hist

        ns['norm'] = norm
        ns['svd'] = svd

        ns['sind'] = oksignal.sind
        ns['cosd'] = oksignal.cosd
        ns['tand'] = oksignal.tand
        ns['arcsind'] = oksignal.arcsind
        ns['arccosd'] = oksignal.arccosd
        ns['arctand'] = oksignal.arctand

        ns['db2'] = oksignal.db2
        ns['nextpow2'] = oksignal.nextpow2
        ns['save_vars'] = save_vars
        ns['load_vars'] = load_vars
        ns['imagesc'] = imagesc


def set_matplotlib_backend(backend):
    r"""Matplotlib의 backend를 설정

    Parameters
    ----------
    backend : {'Qt5Agg', 'TkAgg', 'WebAgg'}
        'Qt5Agg', 'TkAgg', 'WebAgg'

    Returns
    -------
    None
    """
    import sys

    get_trace = getattr(sys, 'gettrace', None)
    if get_trace() is None:
        import matplotlib as mpl
        mpl.use(backend, warn=False)

        mpl.rcParams['webagg.open_in_browser'] = True
        print('MatPlotLib Using:{:}'.format(mpl.get_backend()))
    elif backend.lower() == 'webagg':
        print('Ignore set WebAgg in debug')


if __name__ == "__main__":
    load_func_frequently(globals())

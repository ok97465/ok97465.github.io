"""Init oklib package."""

# Matlab command
import numpy as np
import matplotlib.pyplot as plt
from scipy.special import sindg, cosdg, tandg
from oklib.signal import db2, nextpow2, arcsindg, arccosdg, arctandg
from oklib.plot_ok import imagesc
from oklib.plot_qt import imagescqt, plotqt
from oklib.file import save_vars, load_vars
from matplotlib.pyplot import plot, hist, figure, subplots
from numpy import (
    pi, deg2rad, rad2deg, unwrap, angle, zeros, array, ones, linspace, cumsum,
    diff, arange, interp, conj, exp, sqrt, vstack, hstack, dot, cross, newaxis)
from numpy import cos, sin, tan, arcsin, arccos, arctan
from numpy import amin, amax, argmin, argmax, mean
from numpy.linalg import svd, norm
from numpy.fft import fftshift, ifftshift
from mkl_fft import fft, ifft, fft2, ifft2
from mkl_random import randn, standard_normal, randint, choice, uniform
from mayavi.mlab import surf
from jupyterthemes import jtplot
jtplot.style('grade3')


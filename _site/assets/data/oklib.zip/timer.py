# -*- coding: utf-8 -*-
r"""시간 측정 관련 함수.  # noqa: 501.

[Description]

Example
-------
[example]

Notes
-----
[Notes]

References
----------
.. [] 책: 저자명. (년). 챕터명. In 편집자명 (역할), 책명 (쪽). 발행지 : 발행사
.. [] 학위 논문: 학위자명, "논문제목", 대학원 이름 석사 학윈논문, 1990
.. [] 저널 논문: 저자. "논문제목". 저널명, . pp.

:File name: timer.py
:author: ok97465
:Date created:
"""
import time
from contextlib import contextmanager

@contextmanager
def measure_time(name=''):
    """시간(Wall-clock)을 측정한다. Decorator와 ContextManager로 사용 될 수 있다."""
    start_time = time.time()
    print(f"{name} ===> ", end='')
    yield
    end_time = time.time()
    print(f'Elapsed time: {end_time - start_time:.8f} sec')

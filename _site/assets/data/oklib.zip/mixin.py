# -*- coding: utf-8 -*-
"""Mixin Class.

Created on Wed Aug  7 11:08:47 2019

@author: 71815

"""
# Standard library imports
from pprint import pformat

# Third party imports
from numpy.core.numeric import ndarray


class SlotsToStrMixin:
    """Instance의 __slots__를 출력하는 Class."""

    __slots__ = ()

    def to_dict(self):
        """__slots__ List[Dict]로 변환한다."""
        ret = []

        # base __slots__을 가져온다.
        for slots in [getattr(cls, '__slots__', [])
                      for cls in type(self).__mro__]:
            if slots:
                ret.append(self._traverse_slot(slots))

        return ret

    def _traverse_slot(self, instance_slot):
        """__slots__의 속성을 dict형태로 변환한다."""
        output = {}

        for key in instance_slot:
            try:
                value = self.__getattribute__(key)
                output[key] = self._traverse(key, value)
            except AttributeError:
                pass

        return output

    def _traverse_dict(self, instance_dict):
        """dict를 serialize 한다."""
        output = {}

        for key, value in instance_dict.items():
            output[key] = self._traverse(key, value)

        return output

    def _traverse(self, key, value):
        if isinstance(value, dict):
            return self._traverse_dict(value)
        elif isinstance(value, list):
            return [self._traverse(key, i) for i in value]
        elif isinstance(value, ndarray):
            if value.size > 0:
                return value
            else:
                return f'ndarray => {value.dtype}, {value.shape}'
        elif hasattr(value, '__dict__'):
            return self._traverse_dict(value.__dict__)
        elif hasattr(value, '__slot__'):
            return self._traverse_slot(value.__slot__)
        else:
            return value

    def __repr__(self):
        """Override __repr__."""
        slots_str = ''
        for _dict in self.to_dict():
            slots_str += pformat(_dict)
            slots_str += '\n'
        return slots_str


class ToDictMixin:
    """Instance의 __slots__ 혹은 __dict__를 출력하는 Class."""

    def to_dict(self):
        """__slots__ 혹은 __dict__을 Dict로 변환한다."""
        if hasattr(self, '__slots__'):
            return self._traverse_slot(self.__slots__)
        else:
            return self._traverse_dict(self.__dict__)

    def _traverse_slot(self, instance_slot):
        """__slots__의 속성을 dict형태로 변환한다."""
        output = {}

        for key in instance_slot:
            try:
                value = self.__getattribute__(key)
                output[key] = self._traverse(key, value)
            except AttributeError:
                pass

        return output

    def _traverse_dict(self, instance_dict):
        """dict를 serialize 한다."""
        output = {}

        for key, value in instance_dict.items():
            output[key] = self._traverse(key, value)

        return output

    def _traverse(self, key, value):
        if isinstance(value, dict):
            return self._traverse_dict(value)
        elif isinstance(value, list):
            return [self._traverse(key, i) for i in value]
        elif isinstance(value, ndarray):
            if value.size > 0:
                return value
            else:
                return f'ndarray => {value.dtype}, {value.shape}'
        elif hasattr(value, '__dict__'):
            return self._traverse_dict(value.__dict__)
        elif hasattr(value, '__slot__'):
            return self._traverse_slot(value.__slot__)
        else:
            return value

    def __repr__(self):
        """Override __repr__."""
        return pformat(self.to_dict())

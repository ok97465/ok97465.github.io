"""python 초기화를 위한 모듈."""
# Standard library imports
from multiprocessing import RawArray

# Third party imports
from numpy.core.numeric import frombuffer, ndarray

def ipython_clear(b_plot_close=False):
    """ipython의 변수를 메모리에서 삭제하고 Plot 창을 닫는다.

    Parameters
    ----------
    b_plot_close : bool
        Plot 창을 닫을 지 여부 (the default is False)

    """
    from IPython import get_ipython

    if get_ipython() is not None:
        import sys

        get_trace = getattr(sys, 'gettrace', None)
        if get_trace() is None:
            import gc

            if b_plot_close:
                from matplotlib import pyplot
                figs = list(map(pyplot.figure, pyplot.get_fignums()))
                for fig in figs:
                    fig.clear()
                pyplot.close('all')

            get_ipython().magic('reset -sf')

            gc.collect()


def set_matplotlib_backend(backend):
    r"""Matplotlib의 backend를 설정.

    Parameters
    ----------
    backend : {'Qt5Agg', 'TkAgg', 'WebAgg'}
        'Qt5Agg', 'TkAgg', 'WebAgg'

    Returns
    -------
    None

    """
    import sys

    get_trace = getattr(sys, 'gettrace', None)
    if get_trace() is None:
        import matplotlib as mpl
        mpl.use(backend, warn=False)

        mpl.rcParams['webagg.open_in_browser'] = True
        print('MatPlotLib Using:{:}'.format(mpl.get_backend()))
    elif backend.lower() == 'webagg':
        print('Ignore set WebAgg in debug')


_mkl_max_num_threads = None


def set_mkl_thread(num_thread=None):
    """MKL에서 사용할 Thread 개수를 설정.

    Parameters
    ----------
    num_thread : int, optional
        MKL에서 사용할 Thread 개수 (the default is None)

    """
    import ctypes
    mkl_rt = ctypes.CDLL('mkl_rt.dll')

    global _mkl_max_num_threads
    if _mkl_max_num_threads is None:
        _mkl_max_num_threads = get_mkl_thread()

    if num_thread:
        mkl_rt.MKL_Set_Num_Threads(num_thread)
    else:
        mkl_rt.MKL_Set_Num_Threads(_mkl_max_num_threads)


def get_mkl_thread():
    """MKL에서 사용하는 Thread 개수 반환.

    Returns
    -------
    int
        MKL에서 사용하는 Thread 개수 반환

    """
    import ctypes
    mkl_rt = ctypes.CDLL('mkl_rt.dll')
    num_thread = mkl_rt.MKL_Get_Max_Threads()
    return num_thread


def alloc_shared_ndarray(arr, copy=False):
    """Numpy array와 크기가 동일한 Shared memory를 가지는 ndarray를 생성한다.

    Parameters
    ----------
    arr : ndarray
        Reference array.
    copy : bool
        Copy values of input array to output array.

    Returns
    -------
    ret: ndarray
        ndarray with shared array

    """
    raw_memory = RawArray("b", arr.nbytes)
    ret = frombuffer(raw_memory, dtype=arr.dtype).reshape(arr.shape)

    if copy:
        ret[:] = arr[:]

    return ret

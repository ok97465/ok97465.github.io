# -*- coding: utf-8 -*-
r"""Matplotlib를 이용한 Plot 함수

[Description]

Example
-------
[example]

Notes
-----
[Notes]

References
----------
.. [] 책: 저자명. (년). 챕터명. In 편집자명 (역할), 책명 (쪽). 발행지 : 발행사
.. [] 학위 논문: 학위자명, "논문제목", 대학원 이름 석사 학윈논문, 1990
.. [] 저널 논문: 저자. "논문제목". 저널명, . pp.

:File name: plot_ok.py
:author: ok97465
:Date created:
"""
# Standard library imports
from typing import Iterable, List, Tuple

# Third party imports
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from numpy import ndarray, arange


def get_figsize(n_row, n_col):
    """Subplots의 Figure 크기를 계산한다.

    subplots로 여러 Axes를 그렸을 경우의 Axes 크기가 Figure 하나에 Axes가 하나
    있는 경우와 동일하도록 Figure 크기를 계산한다.

    Parameters
    ----------
    n_row : int
        DESCRIPTION.
    n_col : int
        DESCRIPTION.

    Returns
    -------
    Tuple[int, int]
        DESCRIPTION.

    """
    from matplotlib import rcParams
    size = rcParams['figure.figsize']

    return size[0] * n_col, size[1] * n_row


def _extents(f):
    """Imagesc 함수에서 Axis 조정을 위해 사용 하는 내부 함수.

    Parameters
    ----------
    f : ndarray | Iterable
        축의 값 List

    Returns
    -------
    List[float]
        보정된 축의 시작과 끝

    """
    delta = f[1] - f[0]
    return [f[0] - delta / 2, f[-1] + delta / 2]


def imagesc(
        *arg, colormap=None, aspect='auto',
        title=None, xlabel=None, ylabel=None, colorbar=False,
        colorbar_label='', font_size=None, fontweight='normal',
        tick_font_size=None, tickweight='normal',
        is_grid=False, ax=None, fig=None):
    """Matlab의 Imagesc Wrapper 함수. # noqa: 501.

    Parameters
    ----------
    *arg: Any
        (axis_x, axis_y, data) or (data)
    colormap : str | dict | list | ndarray
        'Greys', 'Greys_r', 'viridis', 'jet', 'parula' <- Matlab 2014b (the default is None)
    aspect : str | float
        'auto', 'equal', 숫자 (the default is 'auto')
    title : str, optional
        Figure의 제목 (the default is None)
    xlabel : str, optional
        X축 이름 (the default is None)
    ylabel : str, optional
        Y축 이름 (the default is None)
    colorbar : bool, optional
        Colorbar 사용 여부 (the default is False)
    colorbar_label : str
        Colorbar 이름 (the default is '')
    font_size : int
        글씨 크기 (the default is 10)
    fontweight : str
        'normal', 'bold', 'light', 'medium', 'semibold', 'heavy', 'black'
    tick_font_size: int
        axis의 tick font size
    tickweight: str
        'normal', 'bold', 'light', 'medium', 'semibold', 'heavy', 'black'
    is_grid : Bool, optional
        Grid 여부 (the default is False)
    ax : Axes, optional
        기존의 Axes에 그리고 싶은 경우에 입력한다 (the default is None)
    fig : Figure
        Figure

    Returns
    -------
    (Figure, Axes)
        Figure, Axes

    """
    import matplotlib as mpl
    from matplotlib import pyplot as plt
    from oklib.file import ManipulateIndex

    idx = ManipulateIndex()
    if len(arg) == 1 or isinstance(arg[1], str) or \
       isinstance(arg[1], mpl.colors.LinearSegmentedColormap):
        data = arg[0]
        nr = data.shape[0]
        nc = data.shape[1]
        col_axis_tmp = range(nc)
        row_axis_tmp = range(nr)
        idx.i()
    elif len(arg) >= 3:
        data = arg[2]
        col_axis_tmp = arg[0]
        row_axis_tmp = arg[1]
        idx.i(3)
        if len(col_axis_tmp) != data.shape[1] or \
           len(row_axis_tmp) != data.shape[0]:
            print('Plz Check length of axis variable of imagesc')
            return
    else:
        print('Plz Check argument of imagesc')
        return

    try:
        colormap = arg[idx.i()]
        aspect = arg[idx.i()]
    except IndexError:
        pass

    col_axis = _extents(col_axis_tmp)
    row_axis = _extents(row_axis_tmp)
    row_axis[1], row_axis[0] = row_axis[0], row_axis[1]

    if colormap and colormap.lower() == 'parula':
        _, colormap = get_colormap_parula()
    if isinstance(colormap, dict):
        colormap = mpl.colors.LinearSegmentedColormap('temp_colormap',
                                                      colormap, 3)
    elif isinstance(colormap, list) or isinstance(colormap, ndarray):
        colormap = mpl.colors.ListedColormap(colormap)

    if ax is None:
        fig, ax = plt.subplots()

    im = ax.imshow(data, aspect=aspect, interpolation='none',
                   extent=col_axis + row_axis, origin='upper', cmap=colormap)
    if title:
        ax.set_title(title, fontsize=font_size, fontweight=fontweight)
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=font_size, fontweight=fontweight)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=font_size, fontweight=fontweight)
    if colorbar:
        from mpl_toolkits.axes_grid1 import make_axes_locatable
        divider = make_axes_locatable(ax)
        cax = divider.append_axes('right', size="5%", pad=0.2)
        cbar = fig.colorbar(im, cax=cax)
        cbar.ax.tick_params(labelsize=tick_font_size)

        if isinstance(colorbar_label, str) and colorbar_label != '':
            cbar.set_label(colorbar_label, fontsize=font_size,
                           fontweight=fontweight)

    ax.tick_params(labelsize=tick_font_size)

    if is_grid is False:
        ax.grid(False)
    else:
        ax.grid(True)

    if fig:
        fig.tight_layout()

    return fig, ax


def get_colormap_parula():
    """Matlab 2014b 이상의 Default Colormap.

    Returns
    -------
    List[(float, float, float)]
        List[(R, G, B)]

    """
    from matplotlib.colors import LinearSegmentedColormap

    parula = [[0.2081, 0.1663, 0.5292],
              [0.2116238095, 0.1897809524, 0.5776761905],
              [0.212252381, 0.2137714286, 0.6269714286],
              [0.2081, 0.2386, 0.6770857143],
              [0.1959047619, 0.2644571429, 0.7279],
              [0.1707285714, 0.2919380952, 0.779247619],
              [0.1252714286, 0.3242428571, 0.8302714286],
              [0.0591333333, 0.3598333333, 0.8683333333],
              [0.0116952381, 0.3875095238, 0.8819571429],
              [0.0059571429, 0.4086142857, 0.8828428571],
              [0.0165142857, 0.4266, 0.8786333333],
              [0.032852381, 0.4430428571, 0.8719571429],
              [0.0498142857, 0.4585714286, 0.8640571429],
              [0.0629333333, 0.4736904762, 0.8554380952],
              [0.0722666667, 0.4886666667, 0.8467],
              [0.0779428571, 0.5039857143, 0.8383714286],
              [0.079347619, 0.5200238095, 0.8311809524],
              [0.0749428571, 0.5375428571, 0.8262714286],
              [0.0640571429, 0.5569857143, 0.8239571429],
              [0.0487714286, 0.5772238095, 0.8228285714],
              [0.0343428571, 0.5965809524, 0.819852381],
              [0.0265, 0.6137, 0.8135],
              [0.0238904762, 0.6286619048, 0.8037619048],
              [0.0230904762, 0.6417857143, 0.7912666667],
              [0.0227714286, 0.6534857143, 0.7767571429],
              [0.0266619048, 0.6641952381, 0.7607190476],
              [0.0383714286, 0.6742714286, 0.743552381],
              [0.0589714286, 0.6837571429, 0.7253857143],
              [0.0843, 0.6928333333, 0.7061666667],
              [0.1132952381, 0.7015, 0.6858571429],
              [0.1452714286, 0.7097571429, 0.6646285714],
              [0.1801333333, 0.7176571429, 0.6424333333],
              [0.2178285714, 0.7250428571, 0.6192619048],
              [0.2586428571, 0.7317142857, 0.5954285714],
              [0.3021714286, 0.7376047619, 0.5711857143],
              [0.3481666667, 0.7424333333, 0.5472666667],
              [0.3952571429, 0.7459, 0.5244428571],
              [0.4420095238, 0.7480809524, 0.5033142857],
              [0.4871238095, 0.7490619048, 0.4839761905],
              [0.5300285714, 0.7491142857, 0.4661142857],
              [0.5708571429, 0.7485190476, 0.4493904762],
              [0.609852381, 0.7473142857, 0.4336857143],
              [0.6473, 0.7456, 0.4188],
              [0.6834190476, 0.7434761905, 0.4044333333],
              [0.7184095238, 0.7411333333, 0.3904761905],
              [0.7524857143, 0.7384, 0.3768142857],
              [0.7858428571, 0.7355666667, 0.3632714286],
              [0.8185047619, 0.7327333333, 0.3497904762],
              [0.8506571429, 0.7299, 0.3360285714],
              [0.8824333333, 0.7274333333, 0.3217],
              [0.9139333333, 0.7257857143, 0.3062761905],
              [0.9449571429, 0.7261142857, 0.2886428571],
              [0.9738952381, 0.7313952381, 0.266647619],
              [0.9937714286, 0.7454571429, 0.240347619],
              [0.9990428571, 0.7653142857, 0.2164142857],
              [0.9955333333, 0.7860571429, 0.196652381],
              [0.988, 0.8066, 0.1793666667],
              [0.9788571429, 0.8271428571, 0.1633142857],
              [0.9697, 0.8481380952, 0.147452381],
              [0.9625857143, 0.8705142857, 0.1309],
              [0.9588714286, 0.8949, 0.1132428571],
              [0.9598238095, 0.9218333333, 0.0948380952],
              [0.9661, 0.9514428571, 0.0755333333],
              [0.9763, 0.9831, 0.0538]]
    parula_map = LinearSegmentedColormap.from_list('parula', parula)
    return parula, parula_map


def get_colormap_white_to_bgr():
    """최소 값이 흰색인 Colormap.

    Returns
    -------
    List[(float, float, float)]
        List[(R, G, B)]

    """
    from matplotlib.colors import LinearSegmentedColormap

    jet_mdfy1 = [(1.0000, 1.0000, 1.0000),
                 (0.8571, 0.8571, 1.0000),
                 (0.7143, 0.7143, 1.0000),
                 (0.5714, 0.5714, 1.0000),
                 (0.4286, 0.4286, 1.0000),
                 (0.2857, 0.2857, 1.0000),
                 (0.1429, 0.1429, 1.0000),
                 (0, 0, 1.0000),
                 (0, 0.0625, 1.0000),
                 (0, 0.1250, 1.0000),
                 (0, 0.1875, 1.0000),
                 (0, 0.2500, 1.0000),
                 (0, 0.3125, 1.0000),
                 (0, 0.3750, 1.0000),
                 (0, 0.4375, 1.0000),
                 (0, 0.5000, 1.0000),
                 (0, 0.5625, 1.0000),
                 (0, 0.6250, 1.0000),
                 (0, 0.6875, 1.0000),
                 (0, 0.7500, 1.0000),
                 (0, 0.8125, 1.0000),
                 (0, 0.8750, 1.0000),
                 (0, 0.9375, 1.0000),
                 (0, 1.0000, 1.0000),
                 (0.0625, 1.0000, 0.9375),
                 (0.1250, 1.0000, 0.8750),
                 (0.1875, 1.0000, 0.8125),
                 (0.2500, 1.0000, 0.7500),
                 (0.3125, 1.0000, 0.6875),
                 (0.3750, 1.0000, 0.6250),
                 (0.4375, 1.0000, 0.5625),
                 (0.5000, 1.0000, 0.5000),
                 (0.5625, 1.0000, 0.4375),
                 (0.6250, 1.0000, 0.3750),
                 (0.6875, 1.0000, 0.3125),
                 (0.7500, 1.0000, 0.2500),
                 (0.8125, 1.0000, 0.1875),
                 (0.8750, 1.0000, 0.1250),
                 (0.9375, 1.0000, 0.0625),
                 (1.0000, 1.0000, 0),
                 (1.0000, 0.9375, 0),
                 (1.0000, 0.8750, 0),
                 (1.0000, 0.8125, 0),
                 (1.0000, 0.7500, 0),
                 (1.0000, 0.6875, 0),
                 (1.0000, 0.6250, 0),
                 (1.0000, 0.5625, 0),
                 (1.0000, 0.5000, 0),
                 (1.0000, 0.4375, 0),
                 (1.0000, 0.3750, 0),
                 (1.0000, 0.3125, 0),
                 (1.0000, 0.2500, 0),
                 (1.0000, 0.1875, 0),
                 (1.0000, 0.1250, 0),
                 (1.0000, 0.0625, 0),
                 (1.0000, 0, 0),
                 (0.9375, 0, 0),
                 (0.8750, 0, 0),
                 (0.8125, 0, 0),
                 (0.7500, 0, 0),
                 (0.6875, 0, 0),
                 (0.6250, 0, 0),
                 (0.5625, 0, 0),
                 (0.5000, 0, 0)]

    jet_mdfy1_map = LinearSegmentedColormap.from_list('jet_mdfy1', jet_mdfy1)

    return jet_mdfy1, jet_mdfy1_map

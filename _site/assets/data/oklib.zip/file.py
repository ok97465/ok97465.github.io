# -*- coding: utf-8 -*-
r"""파일 Manipulate.

[Description]

Example
-------
[example]

Notes
-----
[Notes]

References
----------
.. [] 책: 저자명. (년). 챕터명. In 편집자명 (역할), 책명 (쪽). 발행지 : 발행사
.. [] 학위 논문: 학위자명, "논문제목", 대학원 이름 석사 학윈논문, 1990
.. [] 저널 논문: 저자. "논문제목". 저널명, . pp.

:File name: file.py
:author: ok97465
:Date created: 2018-08-03 오후 2:32
"""
import xml.etree.cElementTree as et
from oklib.decorators import measure_time
from typing import List


class ManipulateIndex:
    """Index를 관리한다."""

    def __init__(self, init_idx: int = -1):
        self.idx = init_idx

    def i(self, increment: int = 1) -> int:
        """함수가 불리면 idx attribute를 증가시키고 값을 반환한다."""
        self.idx += increment
        return self.idx


def _is_possible_save_in_dill(value):
    """입력 변수가 dill에서 저장 가능한지 확인.

    Parameters
    ----------
    value : Any
        저장할 변수

    Returns
    -------
    bool
        저장 가능 여부

    """
    import numpy as np
    import tkinter as tk
    from io import IOBase
    from types import FunctionType, ModuleType

    if (isinstance(value, FunctionType)
            or isinstance(value, ModuleType)
            or isinstance(value, type)):
        return False
    if (isinstance(value, IOBase)
            or isinstance(value, np.ufunc)
            or isinstance(value, tk.Tk)):
        return False
    if hasattr(value, '__call__') or hasattr(value, 'figure'):
        return False
    if (not isinstance(value, str)
            and ('pptx' in str(value) or 'Axes' in str(value))):
        return False

    return True


@measure_time('save_vars')
def save_vars(filename, env, **kwargs):
    """env에 저장된 변수를 filename에 저장.

    Parameters
    ----------
    filename : str
        저장할 파일명
    env : dict
        변수가 저장된 NameSpace
    **kwargs :
        A=A, p=p  if save variables are A, p

    Returns
    -------
    None

    Examples
    --------
    save_vars('kk', globals(), A=ABC, p=p)

    """
    import dill
    import os

    name, ext = os.path.splitext(filename)
    if ext == '':
        filename += '.pkl'

    if kwargs == {}:
        variables = dict()
        for key, value in env.items():
            if '__' in key:
                if key[0:2] == '__' and key[-2:] == '__':
                    continue

            if not _is_possible_save_in_dill(value):
                continue

            variables[key] = value
    else:
        variables = kwargs

    with open(filename, 'wb') as fp:
        dill.dump(variables, fp)


@measure_time('load_vars')
def load_vars(filename: str, env: dict):
    """dill을 이용해 저장된 변수를 불러온다.

    Parameters
    ----------
    filename : str
        파일명
    env : dict
        파일에서 불러온 변수를 저장할 NameSpace

    Returns
    -------
    None

    Examples
    --------
    load_vars('kk', globals())

    """
    import os
    import dill

    if not os.path.exists(filename):
        name, ext = os.path.splitext(filename)
        if ext == '':
            filename += '.pkl'

    with open(filename, 'rb') as fp:
        variables = dill.load(fp)
        env.update(variables)


def xml_indent(elem, level=0):
    """XML의 출력에 들여쓰기를 수행.

    Parameters
    ----------
    elem : et.Element
        XML element
    level : int
        (the default is 0)

    """
    i = "\n" + level * "    "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "    "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            xml_indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def element_to_xml_file(elem_list, out_path):
    """XML Element를 파일로 출력.

    Parameters
    ----------
    elem_list : List[et.Element]
        XML element List
    out_path : str
        파일 저장 위치

    """
    with open(out_path, 'w', encoding="utf_8") as fp:
        for idx, elem in enumerate(elem_list):
            xml_indent(elem)
            xml_str = et.tostring(
                elem, encoding='utf_8', method='xml').decode("utf-8")
            if idx > 0:
                xml_str = xml_str.replace(
                    "<?xml version=\'1.0\' encoding=\'utf_8\'?>", "")
            fp.write(xml_str)

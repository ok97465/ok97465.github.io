# -*- coding: utf-8 -*-
r"""Signal Processing.  # noqa: 501.

[Description]

Example
-------
[example]

Notes
-----
[Notes]

References
----------
.. [] 책: 저자명. (발행년). Title of chapter. In 편집자명 (역할), title of book (쪽). 발행지 : 발행사
.. [] 학위 논문: 학위자명, "논문제목", 대학원 이름 석사 학윈논문, 1990
.. [] 저널 논문: 저자. "논문제목". 저널명, . pp.

:File name: signal.py
:author: ok97465
:Date created: 2
"""
# Standard library imports
from typing import Iterable

# Third party imports
import numpy as np
from numba import njit
from numpy import amax, arange, argmax, mean, ndarray, newaxis
from numpy.core.numeric import zeros


# @njit(cache=True)
def arcsindg(val):
    """Return degree result of arcsin."""
    return np.rad2deg(np.arcsin(val))


# @njit(cache=True)
def arccosdg(val):
    """Return degree result of arccos."""
    return np.rad2deg(np.arccos(val))


# @njit(cache=True)
def arctandg(val):
    """Return degree result of arctan."""
    return np.rad2deg(np.arctan(val))


def db2(data, db_range=60.0, db_cut=None, b_normalize=True):
    """20log10(data) 반환.

    Parameters
    ----------
    data: ndarray
        dB 변환 할 데이터
    db_range : float
        dB 변환 Dynamic Range (the default is 60.0)
    db_cut : float, optional
        dB 변환 시 최소값 (the default is None, None이면 미 수행),
        (b_normalize가 True 이면 Normalize 이후 cut 값)
    b_normalize : bool, optional
        최대값을 0으로 변환 여부 (the default is True)

    Returns
    -------
    ndarray
        20log10(data)

    """
    data_abs = np.abs(data)
    max_v = data_abs.max()
    db_max = 20 * np.log10(max_v)

    with np.errstate(divide='ignore'):
        db_data = 20 * np.log10(data_abs)

    db_data[db_data < (db_max - db_range)] = db_max - db_range

    if b_normalize:
        db_data -= db_max

    if db_cut:
        db_data[db_data < db_cut] = db_cut

    return db_data


def nextpow2(val):
    r"""2^P >= abs(x)가 되는 첫번째 P를 반환한다.

    .. math::
        {2}^{P} \ge |x|

    Parameters
    ----------
    val : int | float
        Input

    Returns
    -------
    float
        2^P >= abs(x)가 되는 첫번째 P

    """
    val_abs = np.abs(val)

    exponent = 1

    while exponent < val_abs:
        exponent *= 2

    exponent = np.log2(exponent)

    return exponent


def calc_radix(n_len):
    """Mixed Radix를 이용한 FFT 길이를 계산.

    Parameters
    ----------
    n_len : float
        Signal의 길이

    Returns
    -------
    (int, ndarray)
        (fft 길이, fft 길이 후보군)

    """
    n_len = np.ceil(n_len)
    exponent = nextpow2(n_len)

    candidate_list = [2 ** exponent,
                      3 * 2 ** (exponent - 2),
                      5 * 2 ** (exponent - 3),
                      7 * 2 ** (exponent - 3),
                      9 * 2 ** (exponent - 4),
                      11 * 2 ** (exponent - 4),
                      13 * 2 ** (exponent - 4)]

    candidate = np.array(candidate_list)
    candidate -= n_len
    idx = np.where(candidate > -1)
    len_radix = int(np.amin(candidate[idx]) + n_len)

    return len_radix, candidate

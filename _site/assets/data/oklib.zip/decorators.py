# -*- coding: utf-8 -*-
r"""Decorator 함수 모음.

[Description]

Example
-------
[example]

Notes
-----
[Notes]

:File name: Decorator.py
:author: ok97465
:Date created: 2018-08-03 오후 2:24

"""
# Standard library imports
import time
from contextlib import contextmanager
from dataclasses import asdict
from pprint import pformat


@contextmanager
def measure_time(name=''):
    """시간(Wall-clock)을 측정한다.

    Decorator와 ContextManager로 사용 될 수 있다.

    """
    start_time = time.time()
    print(f'-> {name} ', end='')
    yield
    end_time = time.time()
    print(f'<-: {end_time - start_time:.2f} sec')


def __repr__dataclass(self):
    """Dataclass의 __repr__ function."""
    return pformat(asdict(self))


def dataclass_repr(cls):
    """Decorate for __repr__ dataclass."""
    cls.__repr__ = __repr__dataclass
    return cls

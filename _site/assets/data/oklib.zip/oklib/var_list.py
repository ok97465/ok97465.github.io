# -*- coding: utf-8 -*-
r"""유의미한 변수명을 출력

[Description]

Example
-------
[example]

Notes
-----
[Notes]

:File name: var_list.py
:author: ok97465
:Date created: 2018-08-03 오후 5:55
"""
from sys import getsizeof
from pprint import pprint

try:
    import numpy as np  # noqa: F401
except ImportError:
    pass


def _getsizeof(x):
    # return the size of variable x. Amended version of sys.getsizeof
    # which also supports ndarray, Series and DataFrame
    if type(x).__name__ in ['ndarray', 'Series']:
        return x.nbytes
    elif type(x).__name__ == 'DataFrame':
        return x.memory_usage().sum()
    else:
        return getsizeof(x)


def _getshapeof(x):
    # returns the shape of x if it has one
    # returns None otherwise - might want to return an empty string for an empty collum
    try:
        if len(x.shape) == 1:
            return f'{x.shape[0]:d}({x.dtype})'
        elif len(x.shape) == 2:
            return f'{x.shape[0]:d} x {x.shape[1]:d}({x.dtype})'
        else:
            return x.shape
    except AttributeError:  # x does not have a shape
        try:
            return str(x)
        except:
            return None


def var_dic_list():
    types_to_exclude = ['module', 'function', 'builtin_function_or_method',
                        'instance', '_Feature', 'type', 'ufunc', 'CPUDispatcher', 'ZMQExitAutocall', 'method']
    name_to_exclude = ['pi', 'In', 'Out']
    try:
        from IPython import get_ipython
        ns = get_ipython().user_global_ns
        values = list(get_ipython().user_global_ns.keys())
    except:
        ns = globals()
        values = list(globals().keys())

    # vardic = [[v, type(eval(v, ns)).__name__, str(_getshapeof(eval(v, ns))) if _getshapeof(eval(v, ns)) else '', str(_getsizeof(eval(v, ns)))]  # noqa
    vardic = [[v, type(eval(v, ns)).__name__, str(_getshapeof(eval(v, ns))) if _getshapeof(eval(v, ns)) else '']  # noqa

    for v in values if (v not in ['_html', '_nms', 'NamespaceMagics', '_Jupyter']) and (type(eval(v, ns)).__name__ not in types_to_exclude) and (v[0] != '_') and (v not in name_to_exclude)]  # noqa

    # return json.dumps(vardic)
    return vardic


def wh():
    pprint(var_dic_list())


if __name__ == "__main__":
    wh()

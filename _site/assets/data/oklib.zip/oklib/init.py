def ipython_clear(b_plot_close=False):
    """ipython의 변수를 메모리에서 삭제하고 Plot 창을 닫는다.

    Parameters
    ----------
    b_plot_close : bool
        Plot 창을 닫을 지 여부 (the default is False)

    """

    from IPython import get_ipython

    if get_ipython() is not None:
        import sys

        get_trace = getattr(sys, 'gettrace', None)
        if get_trace() is None:
            import gc

            if b_plot_close:
                from matplotlib import pyplot
                figs = list(map(pyplot.figure, pyplot.get_fignums()))
                for fig in figs:
                    fig.clear()
                pyplot.close('all')

            get_ipython().magic('reset -sf')

            gc.collect()


def set_matplotlib_backend(backend):
    r"""Matplotlib의 backend를 설정

    Parameters
    ----------
    backend : {'Qt5Agg', 'TkAgg', 'WebAgg'}
        'Qt5Agg', 'TkAgg', 'WebAgg'

    Returns
    -------
    None
    """
    import sys

    get_trace = getattr(sys, 'gettrace', None)
    if get_trace() is None:
        import matplotlib as mpl
        mpl.use(backend, warn=False)

        mpl.rcParams['webagg.open_in_browser'] = True
        print('MatPlotLib Using:{:}'.format(mpl.get_backend()))
    elif backend.lower() == 'webagg':
        print('Ignore set WebAgg in debug')


if __name__ == "__main__":
    load_func_frequently(globals())

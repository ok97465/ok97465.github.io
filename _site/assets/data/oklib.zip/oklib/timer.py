# -*- coding: utf-8 -*-
r"""시간 측정 관련 함수

[Description]

Example
-------
[example]

Notes
-----
[Notes]

References
----------
.. [] 책: 저자명. (발행년). Title of chapter. In 편집자명 (역할), title of book (쪽). 발행지 : 발행사
.. [] 학위 논문: 학위자명, "논문제목", 대학원 이름 석사 학윈논문, 1990
.. [] 저널 논문: 저자. "논문제목". 저널명, . pp.

:File name: timer.py
:author: ok97465
:Date created:
"""


def measure_func_time(f_name=''):
    """함수 소요 시간을 출력한다.

    Parameters
    ----------
    f_name : str
        측정 할 함수 이름 (the default is '')
    Returns
    -------
    Any
    """

    import sys
    import time
    from functools import wraps

    def set_decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            print("{:s} ===> ".format(f_name), end='')
            sys.stdout.flush()
            start = time.clock()
            result = func(*args, **kwargs)
            print('Elapsed time: {:.8f} sec'.format(time.clock() - start))
            return result
        return wrapper
    return set_decorator


class Timer:
    """클래스 생성 시점부터 소멸 시점까지의 시간을 출력한다."""

    def __init__(self, func_name: str='this func'):
        self.func_name: str = func_name
        self.time_start: float = 0.0

    def __enter__(self):
        import sys
        import time
        print('{} ==>'.format(self.func_name), end=' ')
        sys.stdout.flush()
        self.time_start = time.clock()
        return self

    def __exit__(self, *args):
        import time
        time_end = time.clock()
        interval = time_end - self.time_start
        print('Elapsed time: {:.8f} sec'.format(interval))

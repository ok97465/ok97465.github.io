# -*- coding: utf-8 -*-
r"""Help Processing.

[Description]

Example
-------
[example]

Notes
-----
[Notes]

:File name: radar.py
:author: ok97465
:Date created: 2019.01.12

"""
from numpy import (
    ndarray, array, complex128, ceil, exp, pi, sin, sqrt, deg2rad, zeros,
    arange, conj)
from numpy.fft import fft, ifft
from numpy.linalg import norm
from oklib.timer import measure_func_time
from numba import njit


class RadarParam:
    """Set Radar Parameter."""

    def __init__(self):
        """Init."""
        self.lv: float = 299792458
        self.fc: float = 9.66e9
        self.fs: float = 80e6
        self.vel: float = 200
        self.prf: float = 1000
        self.chirp_tp: float = 10e-6
        self.chirp_bw: float = 65e6
        self.altitude: float = 6000
        self.squint_rad: float = deg2rad(60)
        self.rs_center: float = 50.23e3
        self.rs_near: float = 50e3
        self.clock_ref: float = 5e6
        self.swath_rs: float = 1e3
        self.n_sample: int = int(
            ceil((2 * self.swath_rs / self.lv * 1.1 + self.chirp_tp
                  ) * self.fs)) + 1


def calc_tg_pos(rs, squint_rad, altitude):
    """Generate Target Position.

    Parameters
    ----------
    rs : float
        slant range[m]
    squint_rad : float
        squint [rad]
    altitude : float
        altitude [m]

    Returns
    -------
    ndarray
        tg_pos [cross_track, azimuth, 0]

    """
    rg = sqrt(rs**2 - altitude**2)
    azimuth = rs * sin(squint_rad)
    cross_track = sqrt(rg**2 - azimuth**2)
    return array([cross_track, azimuth, 0])


@measure_func_time
def chirp_data(p_radar, tx_pos, tg_pos, t_first_sample):
    """Generate Chirp Rawdata.

    [description]

    Parameters
    ----------
    p_radar : RadarParam
        Radar Parameter
    tx_pos : ndarray
        Platform Position [n_pulse x 3]
    tg_pos : ndarray
        Target Position [n_target x 3]
    t_first_sample : ndarray
        Sample start time

    Returns
    -------
    ndarray
        ss [n_pulse x n_sample]

    """
    lv = p_radar.lv
    bw = p_radar.chirp_bw
    tp = p_radar.chirp_tp
    fs = p_radar.fs
    fc = p_radar.fc
    kr = bw / tp

    n_pulse, n_sample = tx_pos.shape[0], p_radar.n_sample

    # @njit(parallel=True)
    def _chirp_data():
        ss = zeros((n_pulse, n_sample), dtype=complex128)

        t_base = arange(n_sample) / fs
        for idx in range(n_pulse):
            t_array = t_base + t_first_sample[idx]
            rs_to_tg = norm(tx_pos[idx, :] - tg_pos)
            t_to_tg = 2 * rs_to_tg / lv
            t_to_tg_array = t_array - t_to_tg - tp / 2
            doppler = exp(-1j * 2 * pi * fc * t_to_tg)

            sig = exp(1j * pi * kr * t_to_tg_array ** 2) * doppler

            ss[idx, :] += sig * (
                (t_to_tg_array > -tp/2) & (t_to_tg_array < tp/2))

        return ss
    return _chirp_data()


def compress_chirp(p_radar, ss):
    """Compress Chirp Rawdata.

    Parameters
    ----------
    p_radar : RadarParam
        Radar Parameter
    ss : ndarray
        Chirp Rawdata [n_pulse x n_sample]

    Returns
    -------
    ndarray
        ss_compressed [n_pulse x n_sample]

    """
    bw = p_radar.chirp_bw
    tp = p_radar.chirp_tp
    fs = p_radar.fs
    kr = bw / tp

    n_sample = ss.shape[1]
    n_ref = int(tp * fs)

    t = (arange(n_ref) - n_ref / 2) / fs
    ref = exp(1j * pi * kr * (t**2))

    ref_fft = fft(ref, n=n_sample)
    ss_fft = fft(ss, n=n_sample, axis=1)

    ss_comp = ifft(ss_fft * conj(ref_fft))

    return ss_comp[:, 0:n_sample - n_ref]
